import BudgetSimulator from "@/components/BudgetSimulator";

const Index = () => {
  return <BudgetSimulator />;
};

export default Index;
